/* eslint-disable no-unused-vars */
export {};

declare global {
	interface Window {
		googletag: any;
		dataLayer: any;
	}
}
